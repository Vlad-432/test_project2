Capacitor 6 module for Android MediaProjection.
Package: com.myapp.generated

Files in com/myapp/generated must replace the generated MainActivity.java and be added beside it.
AndroidManifest.xml needs these permissions above <application>:
<uses-permission android:name="android.permission.FOREGROUND_SERVICE"/>
<uses-permission android:name="android.permission.FOREGROUND_SERVICE_MEDIA_PROJECTION"/>

Inside <application> add:
<service android:name="com.myapp.generated.ScreenCaptureService"
 android:exported="false" android:foregroundServiceType="mediaProjection"/>

JS bridge methods:
Capacitor.Plugins.ScreenCapture.startCapture()
Capacitor.Plugins.ScreenCapture.getLatestFrame() -> {mimeType, data(base64)}
Capacitor.Plugins.ScreenCapture.stopCapture()

This module only captures and stores the latest JPEG frame. It does not yet recognize candles or create an overlay.
