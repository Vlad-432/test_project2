package com.myapp.generated;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.media.projection.MediaProjectionManager;
import android.util.Base64;
import com.getcapacitor.ActivityCallback;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import androidx.activity.result.ActivityResult;
import java.io.*;
@CapacitorPlugin(name="ScreenCapture")
public class ScreenCapturePlugin extends Plugin {
 @PluginMethod public void startCapture(PluginCall call) {
  MediaProjectionManager m=(MediaProjectionManager)getContext().getSystemService(Context.MEDIA_PROJECTION_SERVICE);
  if(m==null){call.reject("MediaProjection недоступен");return;}
  startActivityForResult(m.createScreenCaptureIntent(),call,"permissionResult");
 }
 @ActivityCallback private void permissionResult(PluginCall call, ActivityResult result) {
  if(call==null)return;
  if(result.getResultCode()!=Activity.RESULT_OK || result.getData()==null){call.reject("Разрешение не выдано");return;}
  Intent i=new Intent(getContext(),ScreenCaptureService.class);
  i.putExtra(ScreenCaptureService.CODE,result.getResultCode());
  i.putExtra(ScreenCaptureService.DATA,result.getData());
  try {
   if(android.os.Build.VERSION.SDK_INT>=26)getContext().startForegroundService(i); else getContext().startService(i);
   JSObject r=new JSObject();r.put("started",true);call.resolve(r);
  } catch(Exception e){call.reject("Не удалось запустить захват: "+e.getMessage());}
 }
 @PluginMethod public void getLatestFrame(PluginCall call) {
  File f=new File(getContext().getCacheDir(),"screen_capture_latest.jpg");
  if(!f.exists()){call.reject("Кадр ещё не получен");return;}
  try(FileInputStream in=new FileInputStream(f);ByteArrayOutputStream out=new ByteArrayOutputStream()){
   byte[] b=new byte[8192];int n;while((n=in.read(b))>0)out.write(b,0,n);
   JSObject r=new JSObject();r.put("mimeType","image/jpeg");r.put("data",Base64.encodeToString(out.toByteArray(),Base64.NO_WRAP));call.resolve(r);
  }catch(Exception e){call.reject("Ошибка чтения кадра: "+e.getMessage());}
 }
 @PluginMethod public void stopCapture(PluginCall call) {
  getContext().stopService(new Intent(getContext(),ScreenCaptureService.class));call.resolve();
 }
}
