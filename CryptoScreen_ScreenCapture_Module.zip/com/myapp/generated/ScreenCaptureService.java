package com.myapp.generated;
import android.app.*;
import android.content.*;
import android.content.pm.ServiceInfo;
import android.graphics.*;
import android.hardware.display.*;
import android.media.*;
import android.media.projection.*;
import android.os.*;
import android.util.DisplayMetrics;
import android.view.WindowManager;
import java.io.*;
import java.nio.ByteBuffer;
public class ScreenCaptureService extends Service {
 static final String CODE="resultCode", DATA="resultData", CHANNEL="capture_channel";
 MediaProjection projection; VirtualDisplay display; ImageReader reader; HandlerThread thread; Handler handler; long last=0;
 @Override public void onCreate(){
  super.onCreate();
  if(Build.VERSION.SDK_INT>=26){NotificationChannel c=new NotificationChannel(CHANNEL,"Трансляция экрана",NotificationManager.IMPORTANCE_LOW);getSystemService(NotificationManager.class).createNotificationChannel(c);}
  Notification n=new Notification.Builder(this,CHANNEL).setContentTitle("CryptoScreen: захват экрана").setContentText("Трансляция активна").setSmallIcon(android.R.drawable.presence_video_online).setOngoing(true).build();
  if(Build.VERSION.SDK_INT>=29)startForeground(41,n,ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION);else startForeground(41,n);
 }
 @Override public int onStartCommand(Intent i,int flags,int id){
  if(i==null){stopSelf();return START_NOT_STICKY;}
  try{
   MediaProjectionManager m=(MediaProjectionManager)getSystemService(MEDIA_PROJECTION_SERVICE);
   Intent data=i.getParcelableExtra(DATA);int code=i.getIntExtra(CODE,0);
   if(data==null){stopSelf();return START_NOT_STICKY;}
   projection=m.getMediaProjection(code,data);begin();
  }catch(Exception e){stopSelf();}
  return START_NOT_STICKY;
 }
 void begin(){
  DisplayMetrics dm=new DisplayMetrics();WindowManager wm=(WindowManager)getSystemService(WINDOW_SERVICE);wm.getDefaultDisplay().getRealMetrics(dm);
  int w=dm.widthPixels,h=dm.heightPixels,d=dm.densityDpi;
  thread=new HandlerThread("CaptureThread");thread.start();handler=new Handler(thread.getLooper());
  reader=ImageReader.newInstance(w,h,PixelFormat.RGBA_8888,2);
  projection.registerCallback(new MediaProjection.Callback(){@Override public void onStop(){stopSelf();}},handler);
  display=projection.createVirtualDisplay("CryptoScreen",w,h,d,DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,reader.getSurface(),null,handler);
  reader.setOnImageAvailableListener(r->{
   Image image=null;
   try{
    image=r.acquireLatestImage();if(image==null)return;
    long now=System.currentTimeMillis();if(now-last<1000)return;last=now;
    Image.Plane p=image.getPlanes()[0];ByteBuffer b=p.getBuffer();int stride=p.getRowStride(),pixel=p.getPixelStride();
    Bitmap padded=Bitmap.createBitmap(w+(stride-pixel*w)/pixel,h,Bitmap.Config.ARGB_8888);padded.copyPixelsFromBuffer(b);
    Bitmap bmp=Bitmap.createBitmap(padded,0,0,w,h);padded.recycle();
    try(FileOutputStream out=new FileOutputStream(new File(getCacheDir(),"screen_capture_latest.jpg"))){bmp.compress(Bitmap.CompressFormat.JPEG,65,out);}bmp.recycle();
   }catch(Exception ignored){}finally{if(image!=null)image.close();}
  },handler);
 }
 @Override public void onDestroy(){if(display!=null)display.release();if(reader!=null)reader.close();if(projection!=null)projection.stop();if(thread!=null)thread.quitSafely();super.onDestroy();}
 @Override public IBinder onBind(Intent i){return null;}
}
